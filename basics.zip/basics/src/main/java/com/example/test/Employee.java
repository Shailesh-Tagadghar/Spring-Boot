package com.example.test;

import org.springframework.stereotype.Component;

@Component
public class Employee {
	public Employee() {
		System.out.println("Employee Bean Created !");
	}
}
