package com.example.demo.models;

import org.springframework.stereotype.Component;

@Component
public class Person {
	public Person() {
		System.out.println("Person Bean Created !");
	}
}
