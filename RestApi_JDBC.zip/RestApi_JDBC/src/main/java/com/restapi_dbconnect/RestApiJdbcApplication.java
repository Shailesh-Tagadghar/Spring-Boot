package com.restapi_dbconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiJdbcApplication.class, args);
	}

}
